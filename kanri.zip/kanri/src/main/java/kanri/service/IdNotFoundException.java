package kanri.service;

//Id 못 찾았을 때 예외 처리
public class IdNotFoundException extends RuntimeException {

}
